import ti_rover as rv

rv.grid_origin()

#trajet 1
rv.to_xy(4,8,0.23,"m/s")

#trajet 2
rv.to_xy(8,8,0.15,"m/s")

rv.wait_until_done()

t=rv.waypoint_time()

print("durée SN= ",t," s")
