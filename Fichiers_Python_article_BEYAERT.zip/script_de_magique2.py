from microbit import *
from mb_disp import *
from random import *
from mb_sensr import *
from mb_radio import *

def chiffre():
  display.clear()
  N=randint(1,6)
  display.show(N)
  return N

radio.on()
radio.config(length=32,channel=7,power=6,group=0)

C=chiffre()

while not escape():
  if accelerometer.was_gesture('shake'):
    C=chiffre()
  I=display.read_light_level()
  if I<10:
    while accelerometer.was_gesture('shake')==False:
      display.clear()
      radio.send(str(C))
      
