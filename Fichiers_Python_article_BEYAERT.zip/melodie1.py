#star wars
from microbit import *
from mb_music import *

music.set_volume(255)

music.pitch(392,500)
sleep(50)
music.pitch(392,500)
sleep(50)
music.pitch(392,500)
sleep(100)
music.pitch(311,375)
music.pitch(466,125)
music.pitch(392,500)
music.pitch(311,375)
music.pitch(466,125)
music.pitch(392,750)
