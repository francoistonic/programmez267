from microbit import *
from mb_disp import *
from random import *
from mb_sensr import *

def chiffre():
  display.clear()
  N=randint(1,6)
  display.show(N)
  
display.show("Image.SQUARE")
print("\nCONSIGNE : Secouez la carte\npour lancer le dé")
while not escape():
  if accelerometer.was_gesture('shake'):
    chiffre()
    
�