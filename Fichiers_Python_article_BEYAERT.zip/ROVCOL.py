import ti_rover as rv

def avance():
  rv.motors("ccw",150,"cw",150,0.07)
  rv.color_off()
  
def tournegauche():
  rv.stop()
  rv.color_rgb(0,0,255)
  rv.left(15)
  rv.wait_until_done()
  
def tournedroit():
  rv.stop()
  rv.color_rgb(255,0,255)
  rv.right(15)
  rv.wait_until_done()

while True:
  c=rv.color_measurement()
  if c==3: #bleu
    tournegauche()
  elif c==5: #magenta
    tournedroit()
  elif c==6: #jaune
    rv.stop()
    rv.color_rgb(255,255,0)
    break
  else:
    avance()
    