from microbit import *
from mb_music import *

notes = [
  (392, 500, 50),  # Sol
  (392, 500, 50),  # Sol
  (392, 500, 10),  # Sol
  (311, 375, 0),   # Re
  (466, 125, 0),   # La
  (392, 500, 0),   # Sol
  (311, 375, 0),   # Re
  (466, 125, 0),   # La
  (392, 750, 0),   # Sol
]

for freq, dur, pause in notes:
    music.pitch(freq, dur)
    sleep(pause)
