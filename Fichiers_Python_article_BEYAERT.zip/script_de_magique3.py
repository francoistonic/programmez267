from microbit import *
from mb_radio import *
from mb_disp import *

radio.on()
radio.config(length=32,channel=7,power=6,group=0)

while not escape():
  T=radio.receive()
  if T:
    display.show(T)
  else:
    display.clear()
    
W