# IndexGT
Ce dépôt est relatif à un article du numéro 267 du magazine *Programmez!* de janvier-février 2025. Il consiste en une présentation de [FastHTML](https://www.fastht.ml/) dans le contexte d'un petit projet utilisant également Flask et SQLLite.

D'un point de vue fonctionnel, cette petite application web établit le classement par pays selon le nombre de vainqueurs d'étapes toujours en activité, sur le Tour de France, le Giro et la Vuelta.
